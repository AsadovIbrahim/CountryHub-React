'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var isString = _interopDefault(require('is-string'));
var isArray = _interopDefault(require('is-array'));
var normalizeURL = _interopDefault(require('normalize-url'));

var replaceUrlWithVars = function replaceUrlWithVars(url) {
  var variables = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var regexVariables = /:[-|_|\w]+/g;
  var arrayVariables = url.match(regexVariables) || [];
  return arrayVariables.reduce(function (previous, current) {
    var value = variables[current.replace(':', '')] || current;
    return previous.replace(current, value);
  }, url);
};

var joinPathArray = function joinPathArray(paths) {
  return paths.join('/');
};

var createUrl = function createUrl(paths, variables) {
  if (isString(paths)) {
    return replaceUrlWithVars(paths, variables);
  }
  if (isArray(paths)) {
    return replaceUrlWithVars(joinPathArray(paths), variables);
  }
};

var isMergeableObject = function isMergeableObject(value) {
	return isNonNullObject(value)
		&& !isSpecial(value)
};

function isNonNullObject(value) {
	return !!value && typeof value === 'object'
}

function isSpecial(value) {
	var stringValue = Object.prototype.toString.call(value);

	return stringValue === '[object RegExp]'
		|| stringValue === '[object Date]'
		|| isReactElement(value)
}

// see https://github.com/facebook/react/blob/b5ac963fb791d1298e7f396236383bc955f916c1/src/isomorphic/classic/element/ReactElement.js#L21-L25
var canUseSymbol = typeof Symbol === 'function' && Symbol.for;
var REACT_ELEMENT_TYPE = canUseSymbol ? Symbol.for('react.element') : 0xeac7;

function isReactElement(value) {
	return value.$$typeof === REACT_ELEMENT_TYPE
}

function emptyTarget(val) {
	return Array.isArray(val) ? [] : {}
}

function cloneUnlessOtherwiseSpecified(value, options) {
	return (options.clone !== false && options.isMergeableObject(value))
		? deepmerge(emptyTarget(value), value, options)
		: value
}

function defaultArrayMerge(target, source, options) {
	return target.concat(source).map(function(element) {
		return cloneUnlessOtherwiseSpecified(element, options)
	})
}

function mergeObject(target, source, options) {
	var destination = {};
	if (options.isMergeableObject(target)) {
		Object.keys(target).forEach(function(key) {
			destination[key] = cloneUnlessOtherwiseSpecified(target[key], options);
		});
	}
	Object.keys(source).forEach(function(key) {
		if (!options.isMergeableObject(source[key]) || !target[key]) {
			destination[key] = cloneUnlessOtherwiseSpecified(source[key], options);
		} else {
			destination[key] = deepmerge(target[key], source[key], options);
		}
	});
	return destination
}

function deepmerge(target, source, options) {
	options = options || {};
	options.arrayMerge = options.arrayMerge || defaultArrayMerge;
	options.isMergeableObject = options.isMergeableObject || isMergeableObject;

	var sourceIsArray = Array.isArray(source);
	var targetIsArray = Array.isArray(target);
	var sourceAndTargetTypesMatch = sourceIsArray === targetIsArray;

	if (!sourceAndTargetTypesMatch) {
		return cloneUnlessOtherwiseSpecified(source, options)
	} else if (sourceIsArray) {
		return options.arrayMerge(target, source, options)
	} else {
		return mergeObject(target, source, options)
	}
}

deepmerge.all = function deepmergeAll(array, options) {
	if (!Array.isArray(array)) {
		throw new Error('first argument should be an array')
	}

	return array.reduce(function(prev, next) {
		return deepmerge(prev, next, options)
	}, {})
};

var deepmerge_1 = deepmerge;

var NOT_IMPLEMENTED = function NOT_IMPLEMENTED() {
  throw 'This method was not implemented yet';
};

var hasHTTPProtocol = function hasHTTPProtocol(url) {
  return isString(url) && url.startsWith('http');
};

var appendURL = function appendURL() {
  for (var _len = arguments.length, pieces = Array(_len), _key = 0; _key < _len; _key++) {
    pieces[_key] = arguments[_key];
  }

  return pieces.reduce(function (acc, current) {
    if (isArray(current)) {
      return acc + appendURL.apply(null, current);
    }

    if (hasHTTPProtocol(current)) {
      return current;
    }

    return acc + '/' + current;
  }, '');
};

var normalizeURL$1 = (function () {
  for (var _len2 = arguments.length, pieces = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    pieces[_key2] = arguments[_key2];
  }

  return function () {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    var completeURL = appendURL(pieces);
    var hasParams = !!completeURL.includes('?');
    return normalizeURL('' + completeURL + (hasParams ? '' : '/'), options);
  };
});

var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

var defineProperty = function (obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
};

var DEFAULT_OPTIONS = {
  requestType: 'json',
  request: {},
  uri: {
    removeTrailingSlash: false
  }
};

var Client = function () {
  function Client(uri) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    classCallCheck(this, Client);

    this.options = deepmerge_1(DEFAULT_OPTIONS, options);
    this.uri = normalizeURL$1(uri)(this.options.uri);

    if (this.options.requestType !== DEFAULT_OPTIONS.requestType) {
      NOT_IMPLEMENTED();
    }
    this.requestType = this.options.requestType;
  }

  createClass(Client, [{
    key: 'getURI',
    value: function getURI() {
      return this.uri;
    }
  }, {
    key: 'getRequestType',
    value: function getRequestType() {
      return this.requestType;
    }
  }], [{
    key: 'appendToURI',
    value: function appendToURI(client) {
      var uri = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

      return normalizeURL$1([client.getURI(), uri])(client.options.uri);
    }
  }]);
  return Client;
}();

var createClient = function createClient(uri, options) {
  return new Client(uri, options);
};

var isUndefined = function isUndefined(value) {
  return typeof value === 'undefined';
};

var compactObject = (function (raw) {
  return raw && Object.keys(raw).filter(function (key) {
    return !isUndefined(raw[key]);
  }).reduce(function (obj, key) {
    return Object.assign({}, obj, defineProperty({}, key, raw[key]));
  }, {});
});

var buildQueryString = (function (params) {
  return Object.keys(params).map(function (k) {
    if (Array.isArray(params[k])) {
      return params[k].map(function (val) {
        return encodeURIComponent(k) + '[]=' + encodeURIComponent(val);
      }).join('&');
    }
    return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
  }).join('&');
});

var appendParams = function appendParams() {
  var url = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
  var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  var cleanParams = compactObject(params);
  if (cleanParams && Object.keys(cleanParams).length) {
    return (url || '') + '?' + buildQueryString(cleanParams);
  }
  return url || '';
};

var isClientInstance = function isClientInstance(client$$1) {
  if (client$$1 instanceof Client) {
    return true;
  }
  return false;
};

var getDefaultOptions = function getDefaultOptions(client$$1) {
  switch (client$$1.getRequestType()) {
    case 'json':
      return {
        headers: {
          'content-type': 'application/json; charset=UTF-8'
        }
      };
    default:
      throw 'Request type not allowed';
  }
};

var request = function request(client$$1, method) {
  var appendToURI = Client.appendToURI.bind(null, client$$1);
  var DEFAULT_OPTIONS = getDefaultOptions(client$$1);
  var HTTP_METHOD = { method: method };

  return function (uri) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return fetch(appendToURI(!!uri ? uri : ''), deepmerge_1.all([DEFAULT_OPTIONS, client$$1.options.request, options, HTTP_METHOD]));
  };
};

var getHTTPMethods = function getHTTPMethods(client$$1) {
  if (!isClientInstance(client$$1)) {
    throw 'Please specify a Client to get the http methods.';
  }

  var clientRequest = request.bind(null, client$$1);

  return {
    post: function post(uri) {
      var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return clientRequest('POST')(uri, deepmerge_1(options, { body: JSON.stringify(data) }));
    },
    get: function get(uri) {
      var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return clientRequest('GET')(appendParams(uri, params), options);
    },
    upload: function upload(uri) {
      var formData = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : new FormData();
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return clientRequest('POST')(uri, deepmerge_1.all([options, {
        body: formData,
        headers: formData.getHeaders()
      }, {
        headers: {
          Accept: 'application/json, application/xml, text/plain, text/html, *.*',
          'content-type': 'application/x-www-form-urlencoded; charset=utf-8'
        }
      }]));
    },
    patch: function patch(uri) {
      var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return clientRequest('PATCH')(uri, deepmerge_1(options, { body: JSON.stringify(data) }));
    },
    put: function put(uri) {
      var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return clientRequest('PUT')(uri, deepmerge_1(options, { body: JSON.stringify(data) }));
    },
    delete: function _delete(uri) {
      var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
      return clientRequest('DELETE')(uri, deepmerge_1(options, { body: JSON.stringify(data) }));
    }
  };
};

exports.createUrl = createUrl;
exports.Client = Client;
exports.createClient = createClient;
exports.getHTTPMethods = getHTTPMethods;
